A simple 3rd Person Controller to be used in godot 3
The controller must be a child of a KinematicBody and you must register the Kinematic Body in the controller inspector
A simple Test scene is included to show how it works
